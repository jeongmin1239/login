<?php
// save_song.php
require_once 'db.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_idx'])) {
    echo json_encode(['success' => false, 'message' => '로그인이 필요합니다.']);
    exit;
}

$user_idx = $_SESSION['user_idx'];
$url = $_POST['url'] ?? '';
$comment = $_POST['comment'] ?? '';
$title = $_POST['title'] ?? '';
$thumb = $_POST['thumb'] ?? '';

// 데이터 저장
$sql = "INSERT INTO songs (user_idx, url, title, thumb, comment, reg_date) 
        VALUES ('$user_idx', '$url', '$title', '$thumb', '$comment', NOW())";

if (mysqli_query($conn, $sql)) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'message' => '저장 실패: ' . mysqli_error($conn)]);
}
?>