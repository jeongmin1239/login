<?php
// api.php
require_once 'db.php';

header('Content-Type: application/json');

$action = $_GET['action'] ?? '';

// 로그인 체크
if (!isset($_SESSION['user_idx'])) {
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

$user_idx = $_SESSION['user_idx'];

if ($action === 'check_today_recommend') {
    // 오늘 이미 등록했는지 확인 (songs 테이블에 오늘 날짜 데이터가 있는지)
    $today = date('Y-m-d');
    $sql = "SELECT id FROM songs WHERE user_idx = '$user_idx' AND DATE(reg_date) = '$today'";
    $result = mysqli_query($conn, $sql);
    
    if (mysqli_num_rows($result) > 0) {
        echo json_encode(['already_done' => true]);
    } else {
        echo json_encode(['already_done' => false]);
    }
}
?>