<?php
// login.php
require_once 'db.php';

header('Content-Type: application/json');

$login_id = $_POST['login_id'] ?? '';
$password = $_POST['password'] ?? '';

$sql = "SELECT * FROM users WHERE login_id = '$login_id'";
$result = mysqli_query($conn, $sql);
$user = mysqli_fetch_assoc($result);

if ($user && password_verify($password, $user['password'])) {
    // 세션 저장
    $_SESSION['user_idx'] = $user['id']; // 유저 고유 번호
    $_SESSION['username'] = $user['username'];
    
    echo json_encode([
        'success' => true,
        'redirect' => '../html/main.html'
    ]);
} else {
    echo json_encode([
        'success' => false,
        'message' => '아이디 또는 비밀번호가 일치하지 않습니다.'
    ]);
}
?>