<?php
// signup.php
require_once 'db.php';

header('Content-Type: application/json');

$email = $_POST['email'] ?? '';
$username = $_POST['username'] ?? '';
$login_id = $_POST['login_id'] ?? '';
$password = $_POST['password'] ?? '';

// 아이디 중복 체크
$check_sql = "SELECT id FROM users WHERE login_id = '$login_id'";
$result = mysqli_query($conn, $check_sql);

if (mysqli_num_rows($result) > 0) {
    echo json_encode(['success' => false, 'message' => '이미 존재하는 아이디입니다.']);
    exit;
}

// 비밀번호 암호화 (보안 권장)
$hashed_password = password_hash($password, PASSWORD_DEFAULT);

$sql = "INSERT INTO users (email, username, login_id, password) VALUES ('$email', '$username', '$login_id', '$hashed_password')";

if (mysqli_query($conn, $sql)) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'message' => '회원가입 실패: ' . mysqli_error($conn)]);
}
?>