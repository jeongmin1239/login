<?php
// db.php
session_start();

$host = 'localhost';
$user = 'root'; // DB 아이디
$pass = '1234'; // DB 비밀번호
$db   = 'login';   // DB 이름

$conn = mysqli_connect($host, $user, $pass, $db);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// 한글 깨짐 방지
mysqli_set_charset($conn, "utf8mb4");
?>