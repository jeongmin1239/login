<?php
// 1. 세션 시작 (로그인 여부 확인용)
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// 2. 로그인 세션(user_idx)이 있는지 확인
if (isset($_SESSION['user_idx'])) {
    // 로그인이 되어 있다면 메인 화면으로 이동
    header("Location: html/main.html");
    exit;
} else {
    // 로그인이 안 되어 있다면 로그인 화면으로 이동
    header("Location: html/login.html");
    exit;
}
?>